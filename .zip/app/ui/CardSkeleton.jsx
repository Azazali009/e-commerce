import React from "react";

const CardSkeleton = () => {
  return <div className=" skeleton h-[30rem] w-full"></div>;
};

export default CardSkeleton;
