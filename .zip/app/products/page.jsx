import React from "react";
import Products from "../components/products/products";
import Sidebar from "../components/sidebar/Sidebar";

const ProductPage = () => {
  return (
    <div className=" ">
      <Products />
    </div>
  );
};

export default ProductPage;
