import { Smooch } from "next/font/google";

export const smooch = Smooch({
  subsets: ["latin"],
  style: ["normal"],
  weight: ["400"],
});
